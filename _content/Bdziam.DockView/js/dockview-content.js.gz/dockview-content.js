﻿export class DockviewPanelContent {
    constructor(option) {
        this.option = option
    }

    init(parameter) {
        const { params, api: { panel, accessor: { params: { template } } } } = parameter;
        const { titleClass, titleWidth, class: panelClass, key, title } = params;
        const { tab, content } = panel.view

        if (template) {
            this._element = key
                ? template.querySelector(`[data-b-key="${key}"]`)
                : (template.querySelector(`#${this.option.id}`) ?? template.querySelector(`[data-b-title="${title}"]`))
        }

        if (titleClass) {
            tab._content.classList.add(titleClass);
        }
        if (titleWidth) {
            tab._content.style.width = `${titleWidth}px`;
        }
        if (panelClass) {
            panelClass.split(' ').forEach(className => {
                content.element.classList.add(className);
            });
        }
    }

    get element() {
        return this._element;
    }
}
